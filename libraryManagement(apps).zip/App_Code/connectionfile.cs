﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

/// <summary>
/// Summary description for connectionfile
/// </summary>
///
 
namespace dbconnection
{
public class connectionfile
{
	
            public SqlConnection con;
            public SqlDataAdapter da;
            public SqlDataReader dr;
            public SqlCommand cmd;
            public DataSet ds;
            public DataSet ds1;
         public connectionfile()
        {

            //con = new SqlConnection("Server=.,Authentication=Windows Authentication, Database=DAV");
            // con = new SqlConnection("Server=.;uid=sa; integrated security=true;database=DAV");
            con = new SqlConnection("Server=.;uid=sa;pwd=123; database=website-v1");
            ds = new DataSet();
            ds1 = new DataSet();
        }
         public void mysqlcmd(string query)//insert ,update,delete
         {
             con.Close();
             if (con.State == ConnectionState.Closed)
             {
                 con.Open();
             }
             cmd = new SqlCommand(query, con);
             cmd.ExecuteNonQuery();
             con.Close();
         }
         public DataSet sqldata(string query)//multiple row fetching
         {
             con.Close();
             if (con.State == ConnectionState.Closed)
             {
                 con.Open();
             }
             da = new System.Data.SqlClient.SqlDataAdapter(query, con);
             da.Fill(ds);
             return ds;

         }

         public DataSet sqldata1(string query)//multiple row fetching
         {
             con.Close();
             if (con.State == ConnectionState.Closed)
             {
                 con.Open();
             }
             da = new SqlDataAdapter(query, con);
             da.Fill(ds1);
             return ds1;

         }
         public SqlDataReader sqlreader(string query)//single row fetching
         {
             con.Close();
             if (con.State == ConnectionState.Closed)
             {
                 con.Open();
             }
             cmd = new System.Data.SqlClient.SqlCommand(query, con);
             dr = cmd.ExecuteReader();
             return dr;

         }

         public string Encrypt(string password)
         {
             try
             {
                 byte[] encData_byte = new byte[password.Length];
                 encData_byte = System.Text.Encoding.UTF8.GetBytes(password);
                 string encodedData = Convert.ToBase64String(encData_byte);
                 return encodedData;
             }
             catch (Exception ex)
             {
                 throw new Exception("Error in base64Encode" + ex.Message);
             }
         }

         public string Decrypt(string encodedData)
         {
             System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
             System.Text.Decoder utf8Decode = encoder.GetDecoder();
             byte[] todecode_byte = Convert.FromBase64String(encodedData);
             int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
             char[] decoded_char = new char[charCount];
             utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
             string result = new String(decoded_char);
             return result;
         }
	}
}
